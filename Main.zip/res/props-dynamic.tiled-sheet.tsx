<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="props-dynamic" tilewidth="177" tileheight="108" tilecount="6" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="32" height="64" source="tree1.png"/>
 </tile>
 <tile id="1">
  <image width="32" height="32" source="markerGreen.png"/>
 </tile>
 <tile id="2">
  <image width="32" height="32" source="markerOrange.png"/>
 </tile>
 <tile id="3">
  <image width="177" height="108" source="regem-ludos-sign.png"/>
 </tile>
 <tile id="4">
  <image width="49" height="35" source="bowling-sign2.png"/>
 </tile>
 <tile id="5">
  <image width="75" height="55" source="iso-text/bowl_here.png"/>
 </tile>
</tileset>
