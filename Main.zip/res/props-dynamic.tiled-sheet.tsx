<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="props-dynamic" tilewidth="177" tileheight="108" tilecount="4" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="32" height="64" source="tree1.png"/>
 </tile>
 <tile id="1">
  <image width="32" height="32" source="markerGreen.png"/>
 </tile>
 <tile id="2">
  <image width="32" height="32" source="markerOrange.png"/>
 </tile>
 <tile id="3">
  <image width="177" height="108" source="regem-ludos-sign.png"/>
 </tile>
</tileset>
